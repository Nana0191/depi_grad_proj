# Olist Data Pipeline — Setup Guide

This guide explains how to run the project from a clean machine using Docker Desktop. Follow the steps in order. The commands below are written for **Windows PowerShell**; on macOS/Linux, the Docker commands are the same, but the `AIRFLOW_UID` value may be different.

## 1. Project components

The project uses:

- **SQL Server 2022** — stores the Olist data warehouse (`OlistDW`).
- **Python container** — contains the transformation and SQL Server loading scripts.
- **Apache Airflow 2.10.5** — schedules and orchestrates the pipeline.
- **PostgreSQL for Airflow** — stores Airflow metadata (DAG runs, users, task state).
- **Apache Superset 4.1.1** — provides the analytics dashboard.
- **PostgreSQL for Superset** — stores Superset metadata (users, charts, datasets, dashboards).
- **CloudBeaver** — browser-based SQL client for inspecting SQL Server.
- **GitHub batch repository** — provides the dated CSV batches.

The SQL Server, Airflow metadata, Superset metadata, and CloudBeaver data are stored in separate Docker volumes. A teammate cloning the repository gets **new local volumes**; they do not receive another developer's database or Superset dashboard automatically. The dashboard export included with this project is imported in Step 9.

## 2. Prerequisites

Install the following before starting:

1. **Git** — to clone the project.
2. **Docker Desktop** — use the WSL 2 backend on Windows.
3. Make sure Docker Desktop is running before executing Docker commands.
4. Internet access is required for the first build and for downloading CSV batches from GitHub.

You do not need to install Python, SQL Server, PostgreSQL, Airflow, or Superset directly on your computer. They run inside containers.

Recommended: allow Docker Desktop enough memory for SQL Server, Airflow, PostgreSQL, and Superset to run together.

## 3. Clone the project

Open PowerShell in the folder where you want the project and run:

```powershell
git clone <PROJECT_GITHUB_URL>
cd <PROJECT_FOLDER>
```

Replace the placeholders with the actual GitHub repository URL and folder name.

The batch source repository is separate from the project repository:

- https://github.com/mennaebied15/olist-batched-data

## 4. Create your local `.env` file

The project requires environment variables for SQL Server, Airflow, CloudBeaver, and Superset.

1. Copy `.env.example` and name the copy `.env`:

```powershell
Copy-Item .env.example .env
```

2. Open `.env` and replace every `CHANGE_ME` value with your own local credentials.
3. Keep `.env` on your computer only. **Do not commit or upload `.env` to GitHub.** Commit `.env.example` instead.

Important notes:

- `MSSQL_SA_PASSWORD` must meet SQL Server's password complexity requirements (use at least 8 characters, with uppercase, lowercase, a number, and a symbol).
- Use a long, random `SUPERSET_SECRET_KEY`.
- `AIRFLOW_UID=50000` is the suggested value for this Windows/Docker Desktop setup.
- Avoid special characters such as `@`, `:`, `/`, or `#` in the Airflow/PostgreSQL passwords unless you know how to URL-encode them in connection strings.
- If the SQL Server password contains URL-special characters, URL-encode it when entering the Superset SQLAlchemy connection URI in Step 9.

## 5. Build and start the containers

From the project root (the folder containing `docker-compose.yml`), run:

```powershell
docker compose build
docker compose up -d
```

Check the container status:

```powershell
docker compose ps
```

Wait until `sqlserver`, `airflow-db`, and `superset-db` are healthy. The `airflow-init` service performs Airflow database migration and creates the Airflow admin user from `.env`. It is a one-time initialization service for a fresh Airflow metadata volume.

To inspect startup logs:

```powershell
docker compose logs -f sqlserver
docker compose logs -f airflow-init
docker compose logs -f airflow-webserver
docker compose logs -f airflow-scheduler
docker compose logs -f superset
```

Use `Ctrl+C` to stop following logs; this does not stop the containers.

### Web interfaces

Once the services are running:

| Service | URL | Login |
|---|---|---|
| Airflow | http://localhost:8080 | `AIRFLOW_WWW_USER_USERNAME` / `AIRFLOW_WWW_USER_PASSWORD` from `.env` |
| Superset | http://localhost:8088 | `SUPERSET_ADMIN_USERNAME` / `SUPERSET_ADMIN_PASSWORD` from `.env` |
| CloudBeaver | http://localhost:8978 | `CB_ADMIN_NAME` / `CB_ADMIN_PASSWORD` from `.env` |

SQL Server is exposed on `localhost:1433`.

## 6. Initialize Superset on a fresh machine

The current Compose configuration starts the Superset web service and its PostgreSQL metadata database, but it does **not** automatically run Superset's database migrations or create its admin user. Do this once when the Superset metadata volume is new.

Make sure `superset-db` is running, then execute this from PowerShell in the project root:

```powershell
docker compose run --rm --no-deps --entrypoint /bin/sh superset -c 'superset db upgrade && superset fab create-admin --username "$SUPERSET_ADMIN_USERNAME" --firstname "$SUPERSET_ADMIN_FIRSTNAME" --lastname "$SUPERSET_ADMIN_LASTNAME" --email "$SUPERSET_ADMIN_EMAIL" --password "$SUPERSET_ADMIN_PASSWORD" && superset init'
```

Then start/restart the Superset web service:

```powershell
docker compose up -d superset
```

This initialization command is for a **fresh** Superset metadata database. Do not run the admin-creation part again if the admin user already exists.

## 7. Initialize SQL Server (run these scripts once)

The SQL scripts are mounted inside the Airflow containers at `/app/sql`. The Airflow image includes `sqlcmd`, so use the Airflow webserver container to execute them.

### 7.1 Create the OlistDW database and star schema

```powershell
docker compose exec airflow-webserver bash -c '/opt/mssql-tools18/bin/sqlcmd -S sqlserver -U sa -P "$OLIST_PASSWORD" -C -b -i /app/sql/01_create_schema.sql'
```

This creates the `OlistDW` database and the dimension/fact tables.

### 7.2 Populate the date dimension

```powershell
docker compose exec airflow-webserver bash -c '/opt/mssql-tools18/bin/sqlcmd -S sqlserver -U sa -P "$OLIST_PASSWORD" -C -b -i /app/sql/02_populate_dim_date.sql'
```

This inserts the date rows into `dim_date` (the script expects 1,096 rows).

**Run scripts 01 and 02 only once on a fresh SQL Server volume.** Script 01 creates tables without `IF NOT EXISTS`, and script 02 inserts the date rows. Re-running them on an already initialized database will cause errors or duplicate data. Do not use `docker compose down -v` unless you intentionally want to delete the local database and metadata volumes.

## 8. Run the first data batch through Airflow

The DAG is named `olist_data_pipeline`.

1. Open http://localhost:8080.
2. Sign in with the Airflow credentials from `.env`.
3. Find `olist_data_pipeline` and turn it on.
4. Click **Trigger DAG** to start a manual run.
5. Open the run and follow the tasks in this order:

```text
wait_for_batch
    -> gather_data
    -> transform_data
    -> load_data
    -> validate_sql_data
```

What each task does:

- `wait_for_batch`: checks the GitHub batch repository for all four required CSV files.
- `gather_data`: downloads the files into the shared `data/gathered_data` volume.
- `transform_data`: cleans and validates the CSVs, updates the local processed state, and creates delta files under `data/processed_data/runs/<DATE>`.
- `load_data`: loads the deltas into SQL Server using `--mode incremental` and SQL `MERGE`.
- `validate_sql_data`: runs `sql/04_validation.sql` automatically.

The sensor checks every 5 minutes and gives up after 1 hour if the expected dated folder or any required file is missing. Failed tasks have 3 retries with a 1-minute delay.

### How the DAG chooses the batch date

The DAG uses:

```python
{{ data_interval_end.strftime('%Y-%m-%d') }}
```

That means the expected GitHub folder name must match the rendered `data_interval_end` date, not necessarily the run ID's logical date.

For a manual run, the supplied project logs show that a run on **2026-11-28** requested the folder `2026-11-28`.

For scheduled runs, the DAG runs daily at **08:00 Africa/Cairo**. Since it uses `data_interval_end`, a scheduled run whose logical date is one day earlier can request the following calendar day's folder. Always check the rendered date in the `wait_for_batch` or `gather_data` task logs if a sensor is waiting unexpectedly.

The schedule is `0 8 * * *`, and `catchup=False`.

## 9. Create the SQL views and import the Superset dashboard

### 9.1 Create the analytical views

After the first batch has loaded successfully, run:

```powershell
docker compose exec airflow-webserver bash -c '/opt/mssql-tools18/bin/sqlcmd -S sqlserver -U sa -P "$OLIST_PASSWORD" -C -b -i /app/sql/03_views.sql'
```

This creates/updates:

- `vw_sales_by_category_month`
- `vw_late_delivery_by_state`
- `vw_items_by_seller`

The exported Superset datasets query these views and `fact_sales`. Therefore, create the views before opening the dashboard.

### 9.2 Add the dashboard export to the project

Copy the supplied dashboard export ZIP into the project at:

```text
superset/dashboard_export.zip
```

Keep this export in the GitHub project so teammates can import the same dashboard. It contains the dashboard, seven charts, datasets, and the database definition.

### 9.3 Import the dashboard

Copy the ZIP into the running Superset container:

```powershell
docker compose cp superset/dashboard_export.zip superset:/tmp/olist_dashboard.zip
```

Import it:

```powershell
docker compose exec superset sh -c 'superset import-dashboards -p /tmp/olist_dashboard.zip -u "$SUPERSET_ADMIN_USERNAME"'
```

### 9.4 Reconnect the imported database to the teammate's SQL Server

The exported database configuration contains a masked password (`XXXXXXXXXX`), not the real SQL Server password. After importing:

1. Open http://localhost:8088 and sign in.
2. Go to **Settings → Database Connections**.
3. Open **OlistDW - SQL Server** and edit the connection.
4. Set the SQLAlchemy URI to:

```text
mssql+pymssql://sa:<YOUR_MSSQL_SA_PASSWORD>@sqlserver:1433/OlistDW
```

Replace `<YOUR_MSSQL_SA_PASSWORD>` with the value of `MSSQL_SA_PASSWORD` in your local `.env`. If the password contains URL-special characters, URL-encode them.
5. Save the connection and use **Test Connection** if available.
6. Open the imported dashboard **Olist — Sales & Business Performance**.

The hostname inside Docker must be `sqlserver`, not `localhost`, because Superset connects to the SQL Server service over the Docker network.

## 10. Test the second GitHub batch

The batch source repository is:

https://github.com/mennaebied15/olist-batched-data

The setup package also includes a `sample_batch_2/` folder containing these four CSV files:

```text
customers.csv
orders.csv
order_items.csv
products.csv
```

To publish and test it:

1. Copy the included `sample_batch_2/` folder into the root of the batch source repository.
2. Rename `sample_batch_2` to the required date in `YYYY-MM-DD` format. For a manual test, use **today's date**.
3. The folder must be at the root of the GitHub batch repository, with the CSV files directly inside it. The final structure should look like:

```text
olist-batched-data/
└── YYYY-MM-DD/
    ├── customers.csv
    ├── orders.csv
    ├── order_items.csv
    └── products.csv
```

4. Commit and push that dated folder to the `main` branch of the batch repository.
5. In Airflow, trigger `olist_data_pipeline` manually.
6. Confirm that the date requested in the `wait_for_batch` task matches the folder name you pushed.
7. Wait for all five tasks to succeed. Inspect the task logs if the sensor does not find the batch.

Do not leave the folder named `batch 2`; the DAG searches for a folder whose name is exactly the date string. If the first batch already uses today's date, choose a different unused date for the second test or update the run's expected date consistently.

## 11. Useful checks and commands

Check running containers:

```powershell
docker compose ps
```

Follow Airflow scheduler logs:

```powershell
docker compose logs -f airflow-scheduler
```

Follow Superset logs:

```powershell
docker compose logs -f superset
```

Open a SQL command prompt from the Airflow container:

```powershell
docker compose exec airflow-webserver bash
```

Then, inside the container, `sqlcmd` is available at `/opt/mssql-tools18/bin/sqlcmd`.

Stop containers but keep all data volumes:

```powershell
docker compose down
```

Start them again:

```powershell
docker compose up -d
```

**Warning:** this command deletes the SQL Server, Airflow, Superset, and CloudBeaver volumes and their stored data:

```powershell
docker compose down -v
```

Only use it when you deliberately want a completely fresh local environment.

## 12. GitHub security checklist

Before pushing the project repository:

- Commit `.env.example`, not `.env`.
- Ensure `.env` is listed in `.gitignore`.
- Do not commit Airflow logs, generated gathered CSVs, or processed output/state files.
- Include the dashboard export ZIP because it is a shareable project asset, not a password file.
- Do not include the local `.git` directory from another developer's ZIP.

**Important:** the supplied project ZIP contains a `.env` file that is tracked in its Git history. Removing `.env` from the latest folder is not enough if that history is pushed. If those credentials have already been pushed to any remote, rotate them. For a repository that has not yet been published, start a clean Git history after removing `.env` and the old `.git` directory. If it has already been published, remove the secret from Git history as well as rotating it.

## 13. Expected first-run order (quick checklist)

1. Install Git and Docker Desktop.
2. Clone the project.
3. Create `.env` from `.env.example` and fill in local credentials.
4. Put the dashboard export at `superset/dashboard_export.zip`.
5. Run `docker compose build`.
6. Run `docker compose up -d` and wait for the databases to become healthy.
7. Initialize Superset (`superset db upgrade`, create admin, `superset init`).
8. Run `01_create_schema.sql`.
9. Run `02_populate_dim_date.sql`.
10. Trigger the first Airflow batch and wait for `validate_sql_data` to succeed.
11. Run `03_views.sql`.
12. Import the Superset dashboard and update its SQL Server connection URI.
13. Publish the second dated batch to GitHub and trigger Airflow again to test the next run.
